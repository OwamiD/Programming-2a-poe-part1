﻿using System;

class Ingredient
{
    public string Name { get; set; } // Name of the ingredient
    public double Quantity { get; set; } // Quantity of the ingredient
    public string Unit { get; set; } // Unit of measurement for the ingredient
}

class Step
{
    public string Description { get; set; } // Description of the step
}

class RecipeApp
{
    private Ingredient[] ingredients; // Array to store ingredients
    private Step[] steps; // Array to store steps

    // Method to initialize arrays for ingredients and steps
    public void InitializeRecipe(int ingredientCount, int stepCount)
    {
        ingredients = new Ingredient[ingredientCount];
        steps = new Step[stepCount];
    }

    // Method to set details of an ingredient
    public void SetIngredient(int index, string name, double quantity, string unit)
    {
        ingredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
    }

    // Method to set details of a step
    public void SetStep(int index, string description)
    {
        steps[index] = new Step { Description = description };
    }

    // Method to display the full recipe
    public void DisplayRecipe()
    {
        Console.WriteLine("Recipe Details:");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

    // Method to scale the recipe by a factor
    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    // Method to reset quantities of ingredients to original values
    public void ResetQuantities()
    {
        // Not implemented
    }

    // Method to clear all data
    public void ClearRecipe()
    {
        ingredients = null;
        steps = null;
    }
}