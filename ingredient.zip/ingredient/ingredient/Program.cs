﻿using System;

class Ingredient
{
    public string Name { get; set; } // Name of the ingredient
    public double Quantity { get; set; } // Quantity of the ingredient
    public string Unit { get; set; } // Unit of measurement for the ingredient
}

class Step
{
    public string Description { get; set; } // Description of the step
}

class RecipeApp
{
    private Ingredient[] ingredients; // Array to store ingredients
    private Step[] steps; // Array to store steps

    // Method to initialize arrays for ingredients and steps
    public void InitializeRecipe(int ingredientCount, int stepCount)
    {
        ingredients = new Ingredient[ingredientCount];
        steps = new Step[stepCount];
    }

    // Method to set details of an ingredient
    public void SetIngredient(int index, string name, double quantity, string unit)
    {
        ingredients[index] = new Ingredient { Name = name, Quantity = quantity, Unit = unit };
    }

    // Method to set details of a step
    public void SetStep(int index, string description)
    {
        steps[index] = new Step { Description = description };
    }

    // Method to display the full recipe
    public void DisplayRecipe()
    {
        Console.WriteLine("Recipe Details:");
        Console.WriteLine("Ingredients:");
        foreach (var ingredient in ingredients)
        {
            Console.WriteLine($"{ingredient.Quantity} {ingredient.Unit} of {ingredient.Name}");
        }

        Console.WriteLine("\nSteps:");
        for (int i = 0; i < steps.Length; i++)
        {
            Console.WriteLine($"{i + 1}. {steps[i].Description}");
        }
    }

    // Method to scale the recipe by a factor
    public void ScaleRecipe(double factor)
    {
        foreach (var ingredient in ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    // Method to reset quantities of ingredients to original values
    public void ResetQuantities()
    {
        // Not implemented
    }

    // Method to clear all data
    public void ClearRecipe()
    {
        ingredients = null;
        steps = null;
    }
}

class Program
{
    static void Main(string[] args)
    {
        RecipeApp recipeApp = new RecipeApp();

        Console.WriteLine("Welcome to the Recipe App!");

        // Input the number of ingredients and steps
        Console.Write("Enter the number of ingredients: ");
        int ingredientCount = int.Parse(Console.ReadLine());

        Console.Write("Enter the number of steps: ");
        int stepCount = int.Parse(Console.ReadLine());

        // Initialize the recipe with given counts
        recipeApp.InitializeRecipe(ingredientCount, stepCount);

        // Input details for each ingredient
        for (int i = 0; i < ingredientCount; i++)
        {
            Console.WriteLine($"Enter details for ingredient {i + 1}:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            double quantity;
            while (true)
            {
                Console.Write("Quantity: ");
                if (double.TryParse(Console.ReadLine(), out quantity))
                {
                    break; // Exit the loop if input is a valid double
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid numeric quantity.");
                }
            }
            Console.Write("Unit: ");
            string unit = Console.ReadLine();

            recipeApp.SetIngredient(i, name, quantity, unit);
        }

        // Input details for each step
        for (int i = 0; i < stepCount; i++)
        {
            Console.WriteLine($"Enter step {i + 1}:");
            string description = Console.ReadLine();

            recipeApp.SetStep(i, description);
        }

        // Display the recipe
        Console.WriteLine("\nYour Recipe:");
        recipeApp.DisplayRecipe();

        // Input scaling factor
        Console.WriteLine("\nEnter scaling factor (0.5 for half, 2 for double, 3 for triple): ");
        double factor = double.Parse(Console.ReadLine());
        recipeApp.ScaleRecipe(factor);

        // Display the scaled recipe
        Console.WriteLine("\nRecipe after scaling:");
        recipeApp.DisplayRecipe();

        // Clear all data
        recipeApp.ClearRecipe();

        Console.WriteLine("\nRecipe data cleared. You can enter a new recipe now.");
    }
}
