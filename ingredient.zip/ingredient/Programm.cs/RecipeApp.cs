﻿using System;

internal class RecipeApp
{
    internal void ClearRecipe()
    {
        throw new NotImplementedException();
    }

    internal void DisplayRecipe()
    {
        throw new NotImplementedException();
    }

    internal void InitializeRecipe(int ingredientCount, int stepCount)
    {
        throw new NotImplementedException();
    }

    internal void ScaleRecipe(double factor)
    {
        throw new NotImplementedException();
    }

    internal void SetIngredient(int i, string name, double quantity, string unit)
    {
        throw new NotImplementedException();
    }

    internal void SetStep(int i, string description)
    {
        throw new NotImplementedException();
    }
}