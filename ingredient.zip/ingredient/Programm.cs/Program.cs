﻿using System;

class Program
{
    static void Main(string[] args)
    {
        RecipeApp recipeApp = new RecipeApp();

        Console.WriteLine("Welcome to the Recipe App!");

        // Input the number of ingredients and steps
        Console.Write("Enter the number of ingredients: ");
        int ingredientCount = int.Parse(Console.ReadLine());

        Console.Write("Enter the number of steps: ");
        int stepCount = int.Parse(Console.ReadLine());

        // Initialize the recipe with given counts
        recipeApp.InitializeRecipe(ingredientCount, stepCount);

        // Input details for each ingredient
        for (int i = 0; i < ingredientCount; i++)
        {
            Console.WriteLine($"Enter details for ingredient {i + 1}:");
            Console.Write("Name: ");
            string name = Console.ReadLine();
            double quantity;
            while (true)
            {
                Console.Write("Quantity: ");
                if (double.TryParse(Console.ReadLine(), out quantity))
                {
                    break; // Exit the loop if input is a valid double
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a valid numeric quantity.");
                }
            }
            Console.Write("Unit: ");
            string unit = Console.ReadLine();

            recipeApp.SetIngredient(i, name, quantity, unit);
        }

        // Input details for each step
        for (int i = 0; i < stepCount; i++)
        {
            Console.WriteLine($"Enter step {i + 1}:");
            string description = Console.ReadLine();

            recipeApp.SetStep(i, description);
        }

        // Display the recipe
        Console.WriteLine("\nYour Recipe:");
        recipeApp.DisplayRecipe();

        // Input scaling factor
        Console.WriteLine("\nEnter scaling factor (0.5 for half, 2 for double, 3 for triple): ");
        double factor = double.Parse(Console.ReadLine());
        recipeApp.ScaleRecipe(factor);

        // Display the scaled recipe
        Console.WriteLine("\nRecipe after scaling:");
        recipeApp.DisplayRecipe();

        // Clear all data
        recipeApp.ClearRecipe();

        Console.WriteLine("\nRecipe data cleared. You can enter a new recipe now.");
    }
}